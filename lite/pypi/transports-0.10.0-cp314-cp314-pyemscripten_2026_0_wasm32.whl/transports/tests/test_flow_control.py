"""`autosync` flow control: per-connection coalescing and the explicit slow-consumer policy.

The flush loop never awaits a socket — each connection's undelivered messages live in a per-model
map drained by a fixed writer shard — so one backpressured client cannot stall the broadcast. State
coalesces (new revisions compose into one undelivered patch), bounding a slow consumer's frame count
by its model count; ``max_queue_bytes`` also bounds growing composed payloads. A connection that
exceeds either bound is disconnected (its reconnect resumes via ``open(since=)``).
"""

from __future__ import annotations

import asyncio
import json

import pytest
from pydantic import BaseModel

import transports


class Counter(BaseModel):
    n: int = 0


class Pair(BaseModel):
    x: int = 0
    y: int = 0
    items: list[int] = []


class Payload(BaseModel):
    text: str = ""


class FakeConn:
    def __init__(self) -> None:
        self.sent: list[str | bytes] = []

    async def send_text(self, msg: str) -> None:
        self.sent.append(msg)

    async def send_bytes(self, msg: bytes) -> None:
        self.sent.append(msg)


class StuckConn(FakeConn):
    """A consumer that never drains: its first send blocks forever."""

    async def send_text(self, msg: str) -> None:
        await asyncio.Event().wait()


def test_starlette_websocket_direct_reply_queues_behind_an_inflight_patch():
    class GatedWebSocket(FakeConn):
        def __init__(self) -> None:
            super().__init__()
            self.query_params = {}
            self.incoming: asyncio.Queue[dict] = asyncio.Queue()
            self.gate = asyncio.Event()
            self.started = asyncio.Event()
            self.snapshots_ready = asyncio.Event()
            self.proposal_taken = asyncio.Event()

        async def accept(self) -> None:
            pass

        async def receive(self) -> dict:
            frame = await self.incoming.get()
            if frame.get("text") is not None:
                self.proposal_taken.set()
            return frame

        async def send_text(self, msg: str) -> None:
            decoded = json.loads(msg)
            if decoded["t"] == "patch" and not self.started.is_set():
                self.started.set()
                await self.gate.wait()
            self.sent.append(msg)
            if sum(json.loads(frame)["t"] == "snapshot" for frame in self.sent) == 2:
                self.snapshots_ready.set()

    async def scenario() -> None:
        session = transports.Session()
        blocker = Counter()
        session.host(blocker)
        model = Counter()
        mid = session.host(model)
        server = transports.Server(session)
        conn = GatedWebSocket()
        endpoint = transports.ws_endpoint(server)

        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001))
        endpoint_task = asyncio.get_running_loop().create_task(endpoint(conn))
        try:
            await asyncio.wait_for(conn.snapshots_ready.wait(), timeout=1)
            blocker.n = 1
            model.n = 1
            await asyncio.wait_for(conn.started.wait(), timeout=1)

            proposal = transports.protocol.patch_msg(
                mid,
                {"rev": 2, "ops": [{"Set": {"path": [{"Key": "n"}], "value": {"Int": 2}}}]},
                "edit-1",
            )
            await conn.incoming.put({"text": proposal})
            await asyncio.wait_for(conn.proposal_taken.wait(), timeout=1)
            await asyncio.sleep(0)
            model.n = 3
            await asyncio.sleep(0.01)
            conn.gate.set()
            for _ in range(100):
                target_revs = [
                    message["patch"]["rev"] for frame in conn.sent if (message := json.loads(frame))["t"] == "patch" and message["id"] == mid
                ]
                if len(target_revs) == 3:
                    break
                await asyncio.sleep(0.001)

            target = [message for frame in conn.sent if (message := json.loads(frame))["t"] == "patch" and message["id"] == mid]
            assert [message["patch"]["rev"] for message in target] == [1, 2, 3]
            assert [message.get("proposal") for message in target] == [None, "edit-1", None]
        finally:
            conn.gate.set()
            await conn.incoming.put({"type": "websocket.disconnect"})
            await endpoint_task
            sync_task.cancel()

    asyncio.run(scenario())


def test_starlette_dropped_websocket_cannot_reenter_queue_with_rejected_proposals():
    class FakeWebSocket(FakeConn):
        def __init__(self) -> None:
            super().__init__()
            self.query_params = {}
            self.incoming: asyncio.Queue[dict] = asyncio.Queue()
            self.snapshot_ready = asyncio.Event()
            self.proposals_taken = asyncio.Event()
            self.proposals = 0

        async def accept(self) -> None:
            pass

        async def receive(self) -> dict:
            frame = await self.incoming.get()
            if frame.get("text") is not None:
                self.proposals += 1
                if self.proposals == 3:
                    self.proposals_taken.set()
            return frame

        async def send_text(self, msg: str) -> None:
            self.sent.append(msg)
            if json.loads(msg)["t"] == "snapshot":
                self.snapshot_ready.set()

    async def scenario() -> None:
        session = transports.Session()
        session.host(Counter())
        server = transports.Server(session)
        conn = FakeWebSocket()
        endpoint = transports.ws_endpoint(server)
        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001, shards=1))
        endpoint_task = asyncio.get_running_loop().create_task(endpoint(conn))
        try:
            await asyncio.wait_for(conn.snapshot_ready.wait(), timeout=1)
            server.close(conn)
            invalid = transports.protocol.patch_msg(999, {"rev": 1, "ops": []})
            for _ in range(3):
                await conn.incoming.put({"text": invalid})
            await asyncio.wait_for(conn.proposals_taken.wait(), timeout=1)
            await asyncio.sleep(0.01)

            assert [json.loads(frame)["t"] for frame in conn.sent] == ["snapshot"]
        finally:
            await conn.incoming.put({"type": "websocket.disconnect"})
            await endpoint_task
            sync_task.cancel()

    asyncio.run(scenario())


def test_starlette_direct_reply_does_not_drop_a_healthy_wide_burst():
    class GatedWebSocket(FakeConn):
        def __init__(self) -> None:
            super().__init__()
            self.query_params = {}
            self.incoming: asyncio.Queue[dict] = asyncio.Queue()
            self.gate = asyncio.Event()
            self.started = asyncio.Event()
            self.snapshots_ready = asyncio.Event()
            self.proposal_taken = asyncio.Event()

        async def accept(self) -> None:
            pass

        async def receive(self) -> dict:
            frame = await self.incoming.get()
            if frame.get("text") is not None:
                self.proposal_taken.set()
            return frame

        async def send_text(self, msg: str) -> None:
            decoded = json.loads(msg)
            if decoded["t"] == "patch" and not self.started.is_set():
                self.started.set()
                await self.gate.wait()
            self.sent.append(msg)
            if sum(json.loads(frame)["t"] == "snapshot" for frame in self.sent) == 6:
                self.snapshots_ready.set()

    async def scenario() -> None:
        session = transports.Session()
        models = [Counter() for _ in range(6)]
        mids = [session.host(model) for model in models]
        server = transports.Server(session)
        conn = GatedWebSocket()
        endpoint = transports.ws_endpoint(server)
        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.05, max_queue=4, shards=1))
        endpoint_task = asyncio.get_running_loop().create_task(endpoint(conn))
        try:
            await asyncio.wait_for(conn.snapshots_ready.wait(), timeout=1)
            for model in models:
                model.n = 1
            await asyncio.wait_for(conn.started.wait(), timeout=1)

            proposal = transports.protocol.patch_msg(
                mids[0],
                {"rev": 2, "ops": [{"Set": {"path": [{"Key": "n"}], "value": {"Int": 2}}}]},
            )
            await conn.incoming.put({"text": proposal})
            await asyncio.wait_for(conn.proposal_taken.wait(), timeout=1)
            await asyncio.sleep(0)

            assert conn in server._codecs
            conn.gate.set()
            await asyncio.sleep(0.06)
            assert conn in server._codecs
        finally:
            conn.gate.set()
            await conn.incoming.put({"type": "websocket.disconnect"})
            await endpoint_task
            sync_task.cancel()

    asyncio.run(scenario())


def test_stuck_state_consumer_coalesces_instead_of_disconnecting():
    async def scenario() -> None:
        session = transports.Session()
        model = Counter()
        session.host(model)
        server = transports.Server(session)

        fast, stuck = FakeConn(), StuckConn()
        server.open(fast)
        server.open(stuck)

        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001, max_queue=4))
        try:
            # the stuck consumer's writer is wedged in its first send, but its undelivered state
            # coalesces to one frame per model — one model cannot exceed the entry-count bound
            for expected in range(1, 21):
                model.n = expected
                await asyncio.sleep(0.005)

            # the fast consumer kept receiving throughout — the stuck one never blocked it
            assert len(fast.sent) >= 10

            # bounded by coalescing, the stuck consumer stays connected; when it drains, one
            # frame preserves the queued operations and advances it to the newest revision
            assert stuck in server._codecs
            assert fast in server._codecs
        finally:
            sync_task.cancel()

    asyncio.run(scenario())


@pytest.mark.parametrize("codec", ["json", "msgpack", "cbor"])
def test_stuck_hot_model_exceeding_the_byte_bound_is_disconnected(codec):
    class StuckWireConn(StuckConn):
        async def send_bytes(self, msg: bytes) -> None:
            await asyncio.Event().wait()

    async def scenario() -> None:
        session = transports.Session()
        model = Counter()
        session.host(model)
        server = transports.Server(session)
        fast, stuck = FakeConn(), StuckWireConn()
        server.open(fast, codec=codec)
        server.open(stuck, codec=codec)

        sync_task = asyncio.create_task(transports.autosync(server, interval=0.001, max_queue=1000, max_queue_bytes=512))
        try:
            for expected in range(1, 100):
                model.n = expected
                await asyncio.sleep(0.002)
                if stuck not in server._codecs:
                    break

            assert stuck not in server._codecs
            assert fast in server._codecs
            assert fast.sent
        finally:
            sync_task.cancel()

    asyncio.run(scenario())


def test_byte_bound_allows_a_healthy_wide_flush_with_oversized_frames():
    async def scenario() -> None:
        session = transports.Session()
        models = [Payload() for _ in range(6)]
        for model in models:
            session.host(model)
        server = transports.Server(session)
        conn = FakeConn()
        server.open(conn)

        sync_task = asyncio.create_task(transports.autosync(server, interval=0.001, max_queue_bytes=512))
        try:
            for model in models:
                model.text = "x" * 1024
            for _ in range(1000):
                if len(conn.sent) == len(models):
                    break
                await asyncio.sleep(0.001)
            await asyncio.sleep(0.005)

            assert len(conn.sent) == len(models)
            assert conn in server._codecs
            assert not sync_task.done()
        finally:
            sync_task.cancel()

    asyncio.run(scenario())


def test_stuck_consumer_exceeding_the_bound_is_disconnected():
    async def scenario() -> None:
        session = transports.Session()
        models = [Counter() for _ in range(6)]
        for model in models:
            session.host(model)
        server = transports.Server(session)

        fast, stuck = FakeConn(), StuckConn()
        server.open(fast)
        server.open(stuck)

        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001, max_queue=4))
        try:
            # six models' undelivered revisions cannot coalesce below max_queue=4: the stuck
            # consumer crosses the bound and is disconnected (the explicit policy)
            for expected in range(1, 6):
                for model in models:
                    model.n = expected
                await asyncio.sleep(0.005)

            assert stuck not in server._codecs
            assert fast in server._codecs

            # and the flow keeps working after the disconnect
            before = len(fast.sent)
            models[0].n = 999
            for _ in range(1000):
                if len(fast.sent) > before:
                    break
                await asyncio.sleep(0.001)
            assert len(fast.sent) > before
        finally:
            sync_task.cancel()

    asyncio.run(scenario())


def test_coalescing_delivers_the_newest_revision():
    import json

    class GatedConn(FakeConn):
        """Delivery pauses until `gate` is set, so revisions pile up undelivered."""

        def __init__(self) -> None:
            super().__init__()
            self.gate = asyncio.Event()

        async def send_text(self, msg: str) -> None:
            await self.gate.wait()
            self.sent.append(msg)

    async def scenario() -> None:
        session = transports.Session()
        model = Counter()
        session.host(model)
        server = transports.Server(session)

        gated = GatedConn()
        server.open(gated)

        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001))
        try:
            # revisions land while delivery is gated; each flush composes into the undelivered wire
            for value in (1, 2, 3):
                model.n = value
                await asyncio.sleep(0.005)
            gated.gate.set()
            await asyncio.sleep(0.02)

            # fewer frames than revisions arrive, and the coalesced patch carries the final value
            assert 1 <= len(gated.sent) < 3
            ops = json.loads(gated.sent[-1])["patch"]["ops"]
            assert {"Set": {"path": [{"Key": "n"}], "value": {"Int": 3}}} in ops
        finally:
            sync_task.cancel()

    asyncio.run(scenario())


@pytest.mark.parametrize("codec", ["json", "msgpack", "cbor"])
def test_coalescing_preserves_ops_from_every_revision(codec):
    class GatedConn(FakeConn):
        def __init__(self) -> None:
            super().__init__()
            self.gate = asyncio.Event()
            self.started = asyncio.Event()

        async def send_text(self, msg: str) -> None:
            self.started.set()
            await self.gate.wait()
            self.sent.append(msg)

        async def send_bytes(self, msg: bytes) -> None:
            self.started.set()
            await self.gate.wait()
            self.sent.append(msg)

    async def scenario() -> None:
        session = transports.Session()
        blocker = Counter()
        session.host(blocker)
        model = Pair()
        mid = session.host(model)
        server = transports.Server(session)
        conn = GatedConn()
        client = transports.Client(codec=codec)
        for frame in server.open(conn, codec=codec):
            client.recv(frame)

        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001))
        try:
            blocker.n = 1
            model.x = 1
            model.items.append(1)
            await asyncio.wait_for(conn.started.wait(), timeout=1)
            model.y = 1
            model.items.append(2)
            await asyncio.sleep(0.01)
            conn.gate.set()
            for _ in range(100):
                if len(conn.sent) == 2:
                    break
                await asyncio.sleep(0.001)

            target_frames = [frame for frame in conn.sent if transports.protocol.decode(frame, codec)["id"] == mid]
            assert len(target_frames) == 1
            client.recv(target_frames[0])
            assert client.model(mid, Pair) == Pair(x=1, y=1, items=[1, 2])
        finally:
            conn.gate.set()
            sync_task.cancel()

    asyncio.run(scenario())


def test_broken_custom_codec_drops_only_its_connection():
    codec = "application/x-broken-autosync-test"

    def decode(_wire):
        raise ValueError("broken decoder")

    class GatedConn(FakeConn):
        def __init__(self) -> None:
            super().__init__()
            self.gate = asyncio.Event()
            self.started = asyncio.Event()

        async def send_text(self, msg: str) -> None:
            self.started.set()
            await self.gate.wait()
            self.sent.append(msg)

    async def scenario() -> None:
        transports.register_codec(codec, json.dumps, decode)
        session = transports.Session()
        blocker = Counter()
        session.host(blocker)
        model = Counter()
        mid = session.host(model)
        server = transports.Server(session)
        broken, healthy = GatedConn(), FakeConn()
        server.open(broken, codec=codec)
        server.open(healthy)
        sync_task = asyncio.create_task(transports.autosync(server, interval=0.001))
        try:
            blocker.n = 1
            model.n = 1
            await asyncio.wait_for(broken.started.wait(), timeout=1)
            model.n = 2
            for _ in range(100):
                revisions = [
                    message["patch"]["rev"] for frame in healthy.sent if (message := json.loads(frame))["t"] == "patch" and message["id"] == mid
                ]
                if revisions == [1, 2]:
                    break
                await asyncio.sleep(0.001)

            assert broken not in server._codecs
            assert healthy in server._codecs
            assert revisions == [1, 2]
            assert not sync_task.done()
            broken.gate.set()
            await asyncio.sleep(0.01)
            assert len(broken.sent) == 1
        finally:
            broken.gate.set()
            sync_task.cancel()
            transports.unregister_codec(codec)

    asyncio.run(scenario())


def test_unsizable_custom_codec_drops_only_its_connection():
    codec = "application/x-unsizable-autosync-test"

    async def scenario() -> None:
        transports.register_codec(codec, lambda _message: "\ud800", lambda _wire: {})
        session = transports.Session()
        model = Counter()
        session.host(model)
        server = transports.Server(session)
        broken, healthy = FakeConn(), FakeConn()
        server.open(broken, codec=codec)
        server.open(healthy)
        sync_task = asyncio.create_task(transports.autosync(server, interval=0.001))
        try:
            model.n = 1
            for _ in range(1000):
                if healthy.sent:
                    break
                await asyncio.sleep(0.001)

            assert broken not in server._codecs
            assert healthy in server._codecs
            assert healthy.sent
            assert not sync_task.done()
        finally:
            sync_task.cancel()
            transports.unregister_codec(codec)

    asyncio.run(scenario())


def test_flush_encodes_once_per_codec():
    session = transports.Session()
    model = Counter()
    session.host(model)
    server = transports.Server(session)

    conns = [FakeConn() for _ in range(3)]
    for conn in conns:
        server.open(conn)

    model.n = 7
    out = server.flush()
    assert set(out) == set(conns)
    # same-codec connections share the identical encoded objects, not per-connection copies
    first = out[conns[0]]
    assert all(out[conn] is first for conn in conns[1:])


def test_batch_negotiated_connections_get_one_frame_per_flush():
    import json

    session = transports.Session()
    model = Counter()
    session.host(model)
    server = transports.Server(session)

    plain, batched = FakeConn(), FakeConn()
    server.open(plain)
    server.open(batched, batch=True)

    # several patches in one flush window: the negotiated connection gets one batch frame,
    # the plain connection the individual messages
    model.n = 1
    model.n = 2
    out = server.flush()
    # a single coalesced patch skips the envelope entirely
    assert len(out[plain]) == len(out[batched]) == 1
    assert json.loads(out[batched][0])["t"] == "patch"

    # two models -> two messages per flush -> exactly one enveloped frame for the batched conn
    second = Counter()
    session.host(second)
    model.n = 3
    second.n = 1
    out = server.flush()
    assert len(out[plain]) == 2
    assert len(out[batched]) == 1
    frame = json.loads(out[batched][0])
    assert frame["t"] == "batch"
    assert [m["t"] for m in frame["msgs"]] == ["patch", "patch"]

    # the python client applies a batch in order and returns the accepted changes as a list
    client = transports.Client()
    for msg in server.open(FakeConn()):  # snapshots to seed a mirror
        client.recv(msg)
    model.n = 4
    second.n = 2
    accepted = client.recv(server.flush()[batched][0])
    assert isinstance(accepted, list) and len(accepted) == 2
    assert client.model(next(iter(session.ids())), Counter).n == 4


def test_wedged_socket_is_cut_by_the_watchdog_and_its_shard_resumes():
    async def scenario() -> None:
        session = transports.Session()
        model = Counter()
        session.host(model)
        server = transports.Server(session)

        fast, stuck = FakeConn(), StuckConn()
        server.open(stuck)
        server.open(fast)

        # one shard: the wedged send stalls the healthy consumer too, until the watchdog
        # (probing progress every stall_timeout) cuts the wedged conn and restarts the shard
        sync_task = asyncio.get_running_loop().create_task(transports.autosync(server, interval=0.001, shards=1, stall_timeout=0.05))
        try:
            model.n = 1
            await asyncio.sleep(0.02)
            starved = len(fast.sent)

            await asyncio.sleep(0.25)
            assert stuck not in server._codecs

            model.n = 2
            await asyncio.sleep(0.05)
            assert fast in server._codecs
            assert len(fast.sent) > starved
        finally:
            sync_task.cancel()

    asyncio.run(scenario())
