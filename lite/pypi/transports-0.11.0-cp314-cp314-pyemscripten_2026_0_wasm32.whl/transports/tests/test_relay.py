"""Cross-worker convergence: a client on one worker and a client on another edit the same shared model
concurrently, the writes propagate over a backplane, and both workers' replicas converge — distinct
fields both survive, a conflicting field resolves to the same winner everywhere. This is the CRDT path
(`DeepLwwCrdt`) running across processes through `RelayBroadcaster`'s publish/apply."""

import asyncio
import json
import multiprocessing as mp
import os
import random
import sys
import tempfile
from unittest.mock import patch

import pytest

posix_only = pytest.mark.skipif(sys.platform == "win32", reason="Unix domain sockets are POSIX-only")


def _patch(rev, *kv):
    return {"rev": rev, "ops": [{"Set": {"path": [{"Key": k}], "value": {"Int": v}}} for k, v in kv]}


def _worker(path, idx, patch, result_q):
    """One worker: host the shared model, apply its own write + publish it, apply the other's, report the
    converged value. Re-publishes a few times so the result doesn't depend on connect timing (re-applying
    a write is idempotent under the CRDT — same stamp)."""

    async def go():
        from transports import DeepLwwCrdt, Hub, UnixSocketBackplane

        hub = Hub(key=lambda c: c)
        sid = hub.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)  # first share on each -> same sid
        hub.subscribe(f"t{idx}", sid, "write")
        bp = UnixSocketBackplane(path)
        await bp.start()
        origin = f"t{idx}"

        async def consume():
            async for raw in bp.messages():
                m = json.loads(raw)
                hub.apply_shared(m["sid"], m["patch"], m["origin"])

        ct = asyncio.create_task(consume())
        hub.apply_shared(sid, patch, origin)  # this worker's own client edit
        payload = json.dumps({"sid": sid, "patch": patch, "origin": origin}).encode()
        await asyncio.sleep(0.3)  # let both backplanes connect
        for _ in range(4):
            await bp.publish(payload)
            await asyncio.sleep(0.3)
        ct.cancel()
        await bp.stop()
        result_q.put((idx, hub._shared[sid].value))

    asyncio.run(go())


@posix_only
def test_concurrent_cross_worker_edits_converge():
    path = os.path.join(tempfile.gettempdir(), f"tbp-relay-{os.getpid()}-{random.randint(0, 9999)}.sock")
    patches = {
        0: _patch(1, ("a", 0), ("x", 10)),  # worker 0: unique key "a" + conflicting "x"
        1: _patch(1, ("b", 1), ("x", 11)),  # worker 1: unique key "b" + conflicting "x"
    }
    result_q = mp.Queue()
    procs = [mp.Process(target=_worker, args=(path, i, patches[i], result_q)) for i in (0, 1)]
    for p in procs:
        p.start()
    results = {}
    for _ in procs:
        idx, value = result_q.get(timeout=20)
        results[idx] = value
    for p in procs:
        p.join(timeout=5)
    try:
        os.unlink(path)
    except OSError:
        pass

    assert results[0] == results[1], "replicas did not converge"
    m = results[0]["Map"]
    assert m["a"] == {"Int": 0} and m["b"] == {"Int": 1}, "distinct-field edits should both survive"
    assert m["x"] == {"Int": 11}, "the conflicting field should resolve to the (1,'t1') winner on both"


# --- catch-up + durability (relay logic over a tiny in-process bus) ---

from transports import READ, WRITE, DeepLwwCrdt, Hub, RelayBroadcaster, autosync, protocol, register_codec, unregister_codec, ws_endpoint
from transports.backplane import Backplane


class _Bus:
    def __init__(self):
        self.peers = []


class MemBackplane(Backplane):
    """An in-process backplane for testing relay logic without sockets — peers share a `_Bus`."""

    def __init__(self, bus):
        super().__init__()
        self.bus = bus

    async def _start(self):
        self.bus.peers.append(self)

    async def publish(self, data):
        framed = self._frame(data)
        for p in self.bus.peers:
            if p is not self:
                p._deliver(framed)


class RecordingBackplane(MemBackplane):
    def __init__(self):
        super().__init__(_Bus())
        self.published = []

    async def publish(self, data):
        self.published.append(json.loads(data))


@pytest.mark.parametrize("sync_relay", [False, True], ids=["hub", "relay"])
def test_websocket_relay_autosync_orders_direct_replies(sync_relay):
    class GatedWebSocket:
        def __init__(self):
            self.query_params = {}
            self.incoming = asyncio.Queue()
            self.sent = []
            self.gate = asyncio.Event()
            self.started = asyncio.Event()
            self.snapshot_ready = asyncio.Event()
            self.proposal_taken = asyncio.Event()

        async def accept(self):
            pass

        async def receive(self):
            frame = await self.incoming.get()
            if frame.get("text") is not None:
                self.proposal_taken.set()
            return frame

        async def send_text(self, msg):
            decoded = json.loads(msg)
            if decoded["t"] == "patch" and not self.started.is_set():
                self.started.set()
                await self.gate.wait()
            self.sent.append(msg)
            if decoded["t"] == "snapshot":
                self.snapshot_ready.set()

        async def send_bytes(self, msg):
            raise AssertionError(f"unexpected binary frame: {msg!r}")

    async def go():
        hub = Hub(key=lambda conn: "tenant")
        sid = hub.share({"Map": {"x": {"Int": 0}, "y": {"Int": 0}, "z": {"Int": 0}}}, "Doc")
        hub.subscribe("tenant", sid, WRITE)
        relay = RelayBroadcaster(hub, MemBackplane(_Bus()))
        websocket = GatedWebSocket()
        endpoint = ws_endpoint(relay)
        sync_task = asyncio.create_task(autosync(relay if sync_relay else hub, interval=0.001))
        endpoint_task = asyncio.create_task(endpoint(websocket))
        try:
            await asyncio.wait_for(websocket.snapshot_ready.wait(), timeout=1)
            hub.set_shared(sid, {"Map": {"x": {"Int": 1}, "y": {"Int": 0}, "z": {"Int": 0}}})
            await asyncio.wait_for(websocket.started.wait(), timeout=1)

            proposal = json.dumps(
                {
                    "t": "patch",
                    "id": sid,
                    "patch": {"rev": 2, "ops": [{"Set": {"path": [{"Key": "y"}], "value": {"Int": 1}}}]},
                }
            )
            await websocket.incoming.put({"text": proposal})
            await asyncio.wait_for(websocket.proposal_taken.wait(), timeout=1)
            await asyncio.sleep(0)
            hub.set_shared(sid, {"Map": {"x": {"Int": 1}, "y": {"Int": 1}, "z": {"Int": 1}}})
            await asyncio.sleep(0.01)
            websocket.gate.set()
            for _ in range(100):
                revisions = [
                    message["patch"]["rev"] for frame in websocket.sent if (message := json.loads(frame))["t"] == "patch" and message["id"] == sid
                ]
                if len(revisions) == 3:
                    break
                await asyncio.sleep(0.001)

            assert revisions == [1, 2, 3]
        finally:
            websocket.gate.set()
            await websocket.incoming.put({"type": "websocket.disconnect"})
            await endpoint_task
            sync_task.cancel()

    asyncio.run(go())


def test_relay_and_hub_share_one_autosync_owner():
    async def go():
        hub = Hub(key=lambda conn: conn)
        relay = RelayBroadcaster(hub, MemBackplane(_Bus()))
        sync_task = asyncio.create_task(autosync(hub, interval=0.001))
        try:
            await asyncio.sleep(0)
            with pytest.raises(RuntimeError, match="already running"):
                await autosync(relay, interval=0.001)
        finally:
            sync_task.cancel()

    asyncio.run(go())


def test_relay_keeps_inbound_codec_when_hub_drops_the_connection():
    codec = "application/x-relay-drop-test"

    def encode(value):
        return "custom:" + json.dumps(value)

    def decode(wire):
        return json.loads(wire.removeprefix("custom:"))

    async def go():
        register_codec(codec, encode, decode)
        hub = Hub(key=lambda conn: "tenant")
        sid = hub.share({"Map": {"x": {"Int": 0}}}, "Doc")
        hub.subscribe("tenant", sid, WRITE)
        backplane = RecordingBackplane()
        relay = RelayBroadcaster(hub, backplane)
        conn = object()
        relay.open(conn, codec=codec)
        wire = protocol.encode(
            protocol.patch_msg(sid, {"rev": 1, "ops": [{"Set": {"path": [{"Key": "x"}], "value": {"Int": 1}}}]}),
            codec,
        )
        dropped_wire = protocol.encode(
            protocol.patch_msg(sid, {"rev": 2, "ops": [{"Set": {"path": [{"Key": "x"}], "value": {"Int": 2}}}]}),
            codec,
        )

        def broken_encode(_value):
            raise ValueError("broken encoder")

        register_codec(codec, broken_encode, decode)
        try:
            assert relay.recv(conn, wire) == {}
            await asyncio.sleep(0)
            assert conn not in hub._codecs
            assert hub._shared[sid].value["Map"]["x"] == {"Int": 1}
            assert backplane.published == [
                {
                    "t": "w",
                    "sid": sid,
                    "patch": {"rev": 1, "ops": [{"Set": {"path": [{"Key": "x"}], "value": {"Int": 1}}}]},
                    "origin": "tenant",
                }
            ]
            assert relay.recv(conn, dropped_wire) == {}
            await asyncio.sleep(0)
            assert hub._shared[sid].value["Map"]["x"] == {"Int": 1}
            assert len(backplane.published) == 1
        finally:
            unregister_codec(codec)

    asyncio.run(go())


@pytest.mark.parametrize("subscription", [READ, None], ids=["read-only", "unsubscribed"])
def test_relay_does_not_publish_rejected_shared_write(subscription):
    async def go():
        hub = Hub(key=lambda conn: "tenant")
        sid = hub.share({"Map": {"x": {"Int": 0}}}, "Doc")
        if subscription is not None:
            hub.subscribe("tenant", sid, subscription)
        backplane = RecordingBackplane()
        relay = RelayBroadcaster(hub, backplane)
        conn = object()
        relay.open(conn)
        patch = protocol.patch_msg(sid, {"rev": 1, "ops": [{"Set": {"path": [{"Key": "x"}], "value": {"Int": 1}}}]})

        out = relay.recv(conn, patch)
        await asyncio.sleep(0)

        assert json.loads(out[conn][0])["t"] == "reject"
        assert hub._shared[sid].value["Map"]["x"] == {"Int": 0}
        assert backplane.published == []

    asyncio.run(go())


def test_relay_does_not_publish_write_to_unknown_shared_model():
    async def go():
        hub = Hub(key=lambda conn: "tenant")
        backplane = RecordingBackplane()
        relay = RelayBroadcaster(hub, backplane)
        conn = object()
        relay.open(conn)
        sid = 1 << 40
        patch = protocol.patch_msg(sid, {"rev": 1, "ops": []})

        out = relay.recv(conn, patch)
        await asyncio.sleep(0)

        assert json.loads(out[conn][0])["error"] == "unknown shared model"
        assert backplane.published == []

    asyncio.run(go())


def test_relay_publishes_authorized_shared_write_without_local_delta():
    async def go():
        hub = Hub(key=lambda conn: "tenant")
        sid = hub.share({"Map": {"x": {"Int": 0}}}, "Doc", merge=DeepLwwCrdt)
        hub.subscribe("tenant", sid, WRITE)
        backplane = RecordingBackplane()
        relay = RelayBroadcaster(hub, backplane)
        conn = object()
        relay.open(conn)
        op = {"Set": {"path": [{"Key": "x"}], "value": {"Int": 1}}}

        relay.recv(conn, protocol.patch_msg(sid, {"rev": 2, "ops": [op]}))
        await asyncio.sleep(0)
        rev = hub._shared[sid].rev
        relay.recv(conn, protocol.patch_msg(sid, {"rev": 1, "ops": [op]}))
        await asyncio.sleep(0)

        assert hub._shared[sid].rev == rev
        assert [message["patch"]["rev"] for message in backplane.published] == [2, 1]

    asyncio.run(go())


def test_open_forwards_batch_negotiation_to_hub():
    hub = Hub(key=lambda conn: conn)
    relay = RelayBroadcaster(hub, MemBackplane(_Bus()))
    conn = object()

    with patch.object(hub, "open", wraps=hub.open) as open_hub:
        relay.open(conn, "json", {1: 2}, batch=True)

    open_hub.assert_called_once_with(conn, "json", {1: 2}, batch=True)


def test_late_joiner_catches_up_and_inherits_the_clock():
    async def go():
        bus = _Bus()
        hub_a = Hub(key=lambda c: c)
        sid = hub_a.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)
        relay_a = RelayBroadcaster(hub_a, MemBackplane(bus))
        await relay_a.start(catch_up_timeout=0.2)  # first worker, no peer
        hub_a.apply_shared(sid, _patch(1, ("a", 0), ("x", 10)), "ca")  # A's client edits

        hub_b = Hub(key=lambda c: c)  # B joins late, empty
        hub_b.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)
        relay_b = RelayBroadcaster(hub_b, MemBackplane(bus))
        await relay_b.start(catch_up_timeout=1.0)  # request-for-state -> A answers -> adopt

        assert hub_b._shared[sid].value == hub_a._shared[sid].value, "joiner did not catch up"
        # the merge clock came across too: a stale write (lower stamp) to a caught-up field is dropped
        hub_b.apply_shared(sid, _patch(1, ("x", 999)), "aa")  # (1,'aa') < (1,'ca')
        assert hub_b._shared[sid].value["Map"]["x"] == {"Int": 10}, "stale write should be dropped"

    asyncio.run(go())


def test_durable_restore_recovers_value_rev_and_clock():
    store = {}
    hub = Hub(key=lambda c: c)
    sid = hub.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)
    hub.on_shared_write(lambda s, tn, value, rev, patch, ms: store.update(value=value, rev=rev, ms=ms))
    hub.apply_shared(sid, _patch(1, ("a", 1), ("x", 5)), "ca")
    hub.apply_shared(sid, _patch(2, ("x", 7)), "cb")  # x -> 7, stamp (2,'cb')

    # "full-cluster restart": a fresh hub restores from the user's store
    hub2 = Hub(key=lambda c: c)
    sid2 = hub2.share(store["value"], "Doc", merge=DeepLwwCrdt, rev=store["rev"], merge_state=store["ms"])
    assert hub2._shared[sid2].value == hub._shared[sid].value
    assert hub2._shared[sid2].rev == hub._shared[sid].rev
    hub2.apply_shared(sid2, _patch(1, ("x", 999)), "aa")  # (1,'aa') < (2,'cb') -> dropped (clock restored)
    assert hub2._shared[sid2].value["Map"]["x"] == {"Int": 7}


def test_since_shared_returns_delta_or_none():
    hub = Hub(key=lambda c: c)
    sid = hub.share({"Map": {}}, "Doc", merge=DeepLwwCrdt, replay=True)
    for r in range(1, 4):
        hub.apply_shared(sid, _patch(r, (f"k{r}", r)), f"c{r}")
    assert hub.since_shared(sid, 3) == []  # already current
    replay = hub.since_shared(sid, 1)
    assert replay is not None
    assert len(replay) == 2  # patches for rev 2 and 3
    no_replay = hub.share({"Map": {}}, "Doc2", merge=DeepLwwCrdt)  # replay=False
    assert hub.since_shared(no_replay, 0) is None


def test_late_joiner_with_checkpoint_catches_up_by_delta():
    async def go():
        bus = _Bus()
        hub_a = Hub(key=lambda c: c)
        sid = hub_a.share({"Map": {}}, "Doc", merge=DeepLwwCrdt, replay=True)
        relay_a = RelayBroadcaster(hub_a, MemBackplane(bus))
        await relay_a.start(catch_up_timeout=0.2)
        hub_a.apply_shared(sid, _patch(1, ("a", 1)), "ca")
        hub_a.apply_shared(sid, _patch(2, ("b", 2)), "cb")

        # B restored a stale checkpoint at rev 1 (value has only "a") -> should be sent the rev-2 delta
        hub_b = Hub(key=lambda c: c)
        hub_b.share({"Map": {"a": {"Int": 1}}}, "Doc", merge=DeepLwwCrdt, replay=True, rev=1)
        relay_b = RelayBroadcaster(hub_b, MemBackplane(bus))
        await relay_b.start(catch_up_timeout=1.0)

        assert hub_b._shared[sid].value == hub_a._shared[sid].value, "delta catch-up did not converge"

    asyncio.run(go())


def _alive_worker(path, result_q):
    async def go():
        from transports import DeepLwwCrdt, Hub, RelayBroadcaster, UnixSocketBackplane

        hub = Hub(key=lambda c: c)
        sid = hub.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)
        relay = RelayBroadcaster(hub, UnixSocketBackplane(path))
        await relay.start(catch_up_timeout=0.3)
        hub.apply_shared(sid, _patch(1, ("a", 0), ("x", 10)), "ca")
        await asyncio.sleep(3.0)  # stay up to answer the joiner's request
        result_q.put(("a", hub._shared[sid].value))
        await relay.stop()

    asyncio.run(go())


def _joiner_worker(path, result_q):
    async def go():
        await asyncio.sleep(1.2)  # join after the first worker has edited
        from transports import DeepLwwCrdt, Hub, RelayBroadcaster, UnixSocketBackplane

        hub = Hub(key=lambda c: c)
        hub.share({"Map": {}}, "Doc", merge=DeepLwwCrdt)
        relay = RelayBroadcaster(hub, UnixSocketBackplane(path))
        await relay.start(catch_up_timeout=2.0)  # request-for-state over the real backplane
        result_q.put(("b", hub._shared[next(iter(hub._shared))].value))
        await relay.stop()

    asyncio.run(go())


@posix_only
def test_cross_process_late_joiner_catches_up_over_a_real_backplane():
    path = os.path.join(tempfile.gettempdir(), f"tbp-join-{os.getpid()}-{random.randint(0, 9999)}.sock")
    result_q = mp.Queue()
    procs = [
        mp.Process(target=_alive_worker, args=(path, result_q)),
        mp.Process(target=_joiner_worker, args=(path, result_q)),
    ]
    for p in procs:
        p.start()
    res = {}
    for _ in procs:
        k, v = result_q.get(timeout=20)
        res[k] = v
    for p in procs:
        p.join(timeout=5)
    try:
        os.unlink(path)
    except OSError:
        pass
    assert res["b"] == res["a"], "a worker joining late did not catch up over the backplane"
    assert res["b"]["Map"]["x"] == {"Int": 10}


def test_relay_flush_sweeps_local_inactive_tenants(monkeypatch):
    now = [0.0]
    monkeypatch.setattr("transports.hub.monotonic", lambda: now[0])
    hub = Hub(key=lambda conn: conn, tenant_idle_timeout=5)
    relay = RelayBroadcaster(hub, MemBackplane(_Bus()))
    relay.open("idle")
    relay.close("idle")
    now[0] = 5
    assert relay._flush_tagged() == {}
    assert "idle" not in hub._tenants
